package it.pietrorusso.Argo.Utils;


import java.util.ArrayList;

public class Regione {

    private String nome;
    private ArrayList<ArrayList<String>> contratti_td;
    private ArrayList<ArrayList<String>> contratti_ti;
    private ArrayList<ArrayList<String>> contratti_totali;

    public Regione() {
        contratti_totali = new ArrayList<>();
        contratti_td = new ArrayList<>();
        contratti_ti = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<ArrayList<String>> getContratti_td() {
        return contratti_td;
    }

    public void setContratti_td(ArrayList<ArrayList<String>> contratti_td) {
        this.contratti_td = contratti_td;
    }

    public void updateContratti_td(String anno, String contratti_td) {
        ArrayList<String> t = new ArrayList<>();
        t.add(anno);
        t.add(contratti_td);
        this.contratti_td.add(t);
    }

    public void updateContratti_ti(String anno, String contratti_ti) {
        ArrayList<String> t = new ArrayList<>();
        t.add(anno);
        t.add(contratti_ti);
        this.contratti_ti.add(t);
    }

    public void updateContratti_totali(String anno, String contratti_totali) {
        ArrayList<String> t = new ArrayList<>();
        t.add(anno);
        t.add(contratti_totali);
        this.contratti_totali.add(t);
    }

    public ArrayList<ArrayList<String>> getContratti_ti() {
        return contratti_ti;
    }

    public void setContratti_ti(ArrayList<ArrayList<String>> contratti_ti) {
        this.contratti_ti = contratti_ti;
    }

    public ArrayList<ArrayList<String>> getContratti_totali() {
        return contratti_totali;
    }

    public void setContratti_totali(ArrayList<ArrayList<String>> contratti_totali) {
        this.contratti_totali = contratti_totali;
    }
}
