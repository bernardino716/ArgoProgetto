package it.pietrorusso.Argo.Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {

    private String url = "jdbc:mysql://localhost:3306/";
    private String dbName = "vizometrics?useLegacyDatetimeCode=false&serverTimezone=Europe/Amsterdam&useSSL=false";
    private String driver = "com.mysql.cj.jdbc.Driver";
    private String userName = "root";
    private String password = "saporchia1991";
    private Connection con;

    public Connection getConnection() {
        try {
            Class.forName(driver);
            try {
                con = DriverManager.getConnection(url + dbName, userName, password);
            } catch (SQLException ex) {
                // log an exception. fro example:
                System.out.println("Failed to create the database connection.");
            }
        } catch (ClassNotFoundException ex) {
            // log an exception. for example:
            System.out.println("Driver not found.");
        }
        return con;
    }
}
