package it.pietrorusso.Argo.Utils;

import java.util.ArrayList;

public class Root extends Node {

    private ArrayList<Node> children = new ArrayList<>();


    public Root() {
    }

    public Root(String nome) {
        super(nome);
    }

    public ArrayList<Node> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<Node> children) {
        this.children = children;
    }

    public void add(Node figlio) {
        this.children.add(figlio);
    }

    public void remove(String figlio) {
        for (Node f: this.children) {
            if(f.getName().equals(figlio)) {
                this.children.remove(f);
            }
        }
    }

}
