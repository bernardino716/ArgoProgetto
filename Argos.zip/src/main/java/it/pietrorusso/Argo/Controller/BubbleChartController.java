package it.pietrorusso.Argo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class BubbleChartController {

    @RequestMapping(
            value = "/bubble_chart.html",
            method = RequestMethod.GET
    )
    @ResponseBody
    public ModelAndView MapChartController() {

        return new ModelAndView("/bubble.html");

    }

}
