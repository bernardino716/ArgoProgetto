package it.pietrorusso.Argo.Utils;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

@Controller
public class RegioniExtractor {
    private ConnectionManager cM = new ConnectionManager();

    @RequestMapping(
            value = "/regioni",
            method = RequestMethod.GET,
            produces = "application/json"
    )
    @ResponseBody
    public String MapChartController() {

        Connection connection = cM.getConnection();

        try {

            String query = "SELECT REGIONE, SUBSTRING_INDEX(DATA_INIZIO_RAPPORTO, '/', -1) AS ANNO,\n" +
                    "              COUNT(*) AS 'CONTRATTI_TOTALI',\n" +
                    "              SUM(CLASS_CONTRATTO = 'Tempo determinato') AS 'CONTRATTI_TD',\n" +
                    "              SUM(CLASS_CONTRATTO = 'Tempo indeterminato') AS 'CONTRATTI_TI'\n" +
                    "       FROM\n" +
                    "            (SELECT DESC_REGIONE AS REGIONE, DATA_INIZIO_RAPPORTO, CLASS_CONTRATTO\n" +
                    "              FROM (SELECT DATA_INIZIO_RAPPORTO, CLASS_CONTRATTO, COD_PROVINCIA_SEDELAVORO FROM tab1 WHERE YEAR(CURDATE()) - YEAR(STR_TO_DATE(ID_DT_NASCITA, '%Y%m%d')) BETWEEN 34 AND 41) AS DATA\n" +
                    "              JOIN\n" +
                    "                provincia_regione\n" +
                    "              ON COD_PROVINCIA_SEDELAVORO = `\uFEFFCOD_PROVINCIA`) AS TAB1\n" +
                    "\n" +
                    "       GROUP BY CONCAT(REGIONE ,'-',ANNO)\n" +
                    "       ORDER BY ANNO";

            PreparedStatement st = connection.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            ObjectMapper objm = new ObjectMapper();
            ArrayList<Regione> regioni = new ArrayList<>();

            while (rs.next()) {

                boolean in = false;
                String nome = rs.getString("REGIONE");
                String anno = rs.getString("ANNO");
                String contratti_totali = rs.getString("CONTRATTI_TOTALI");
                String contratti_td = rs.getString("CONTRATTI_TD");
                String contratti_ti = rs.getString("CONTRATTI_TI");

                Regione regione = new Regione();
                regione.setNome(nome);
                regione.updateContratti_totali(anno,contratti_totali);
                regione.updateContratti_td(anno,contratti_td);
                regione.updateContratti_ti(anno, contratti_ti);

                if(!regioni.isEmpty()) {
                    for (Regione r: regioni) {
                        if(r.getNome().equals(nome)) {
                            in = true;
                            r.updateContratti_totali(anno,contratti_totali);
                            r.updateContratti_td(anno,contratti_td);
                            r.updateContratti_ti(anno,contratti_ti);
                            System.out.println("Aggiornata "+nome);
                            break;
                        }
                    }
                }
                if(regioni.isEmpty() || !in){
                    regioni.add(regione);
                    System.out.println("Aggiunta " +nome);
                }
            }

            return objm.writeValueAsString(regioni);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return "error";
    }

}
