package it.pietrorusso.Argo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class MapChartController {

    @RequestMapping(
            value = "/map_chart.html",
            method = RequestMethod.GET
    )
    @ResponseBody
    public ModelAndView MapChartController() {

        return new ModelAndView("map.html");
    }
}
