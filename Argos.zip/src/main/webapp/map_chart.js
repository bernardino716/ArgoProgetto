function drawGraph(filename) {

  d3.json(filename, function (error, data) {
    if (error) console.warn(error);

    d3.select('.d3-tip').remove();
    d3.select('#chart').selectAll('g').remove();
    d3.select('.timeline').remove();
    d3.select('#legend').remove();

    let width = $(window).outerWidth(),
      height = $(window).outerHeight();

    console.log(width, height);

    const container = d3.select('#container')
      .attr('width', width)
      .attr('height', height);

    const chart = d3.select('#chart')
      .attr('width', width)
      .attr('height', height/1.39);

// const timelineScale = d3.scaleTime().domain(d3.extent(['2005', '2016'],function(d){ const parseDate = d3.timeParse('%Y'); return parseDate(d)})).range([0, width/1.25 -50]);
// const timelineAxis = d3.axisBottom(timelineScale).tickFormat(d3.timeFormat("%Y"));
// const timeline = svg.append("g")
//   .attr("id", "timeline")
//   .attr("class", "x axis")
//   .attr("transform", "translate(50,"+ (height - (height/4)) +")")
//   .call(timelineAxis);

    var testData = [
      {class: "leg",  label: "Legislature", times: [
          {"color":"#336BE5", "label":"XIV", "starting_time": new Date(2005, 0, 1), "ending_time": new Date(2006, 4, 27)},
          {"color":"#336BE5", "label":"XV", "starting_time": new Date(2006, 4, 28), "ending_time": new Date(2008, 4, 28)},
          {"color":"#336BE5", "label":"XVI", "starting_time": new Date(2008, 4, 29), "ending_time": new Date(2013, 2, 14)},
          {"color":"#336BE5", "label":"XVII", "starting_time": new Date(2013, 2, 15), "ending_time": new Date(2016, 0, 1)}
        ]
      },
      {class: "law", label: "Regulatory Measure", times: [
          {"color":"#336BE5", "label":"D.L. 02-14-2003, n.30 - Riforma Biagi", "starting_time": new Date(2005, 0, 1), "ending_time":  new Date(2011, 11, 5)},
          {"color":"#336BE5", "label":"D.L. 12-6-2011, n. 201 - Legge Fornero", "starting_time": new Date(2011, 11, 6), "ending_time": new Date(2014, 11, 9)},
          {"color":"#336BE5", "label":"D.L. 12-10-2014, n.183 - Jobs Act", "starting_time": new Date(2014, 11, 10), "ending_time": new Date(2016, 0, 1)},
        ]
      },
    ];

    var tlTip = d3.tip()
      .attr('data-html' , 'true')
      .attr('class', 'd3-tip1')
      .attr('pointer-events', 'none')
      .offset([-10, 0]);

    if(width<480){
      var timelineContainer = d3.timelines()
        .width(width / 1.2)
        .height(150*height/768)
        .itemHeight(15)
        .itemMargin(3)
        .tickFormat({format: d3.timeFormat('%Y'), tickInterval: 1, tickSize: 6})
        .stack()
        .margin({
          left: 55,
          right: Math.round(175 * width / 1708),
          top: 0,
          bottom: 100
        })
        .mouseover(function (d, i, datum) {
// d is the current rendering object
// i is the index during d3 rendering
// datum is the id object

          graph.select('g').selectAll('svg > g > text').attr("pointer-events", "none");

// Create timeline tip
// console.log(d,i,datum);
          if (datum.class == 'leg') {
            tlTip.html(function () {
              return (datum.label+'</br><font size="1px">'+d.label+'</font>');
            });
          }
          else {
            tlTip.html(function () {
              return (datum.label+'</br><font size="1px">'+d.label+'</font></br>'+'<img style=" width:50px; height:15px; display: block;" src="assets/static/images/knowlex.png">');
            });
          }
          graph.call(tlTip);
          tlTip.show();
        })
        .mouseout(function (d, i, datum) {
          tlTip.hide();
        })
        .click(function (d, i, datum) {
          if (datum.class == 'law') {
            window.location = "http://www.isislab.it:20080/knowlex";
          }
        })
        .scroll(function (x, scale) {

        });
    }else {
      if (width <= 720) {
        var timelineContainer = d3.timelines()
          .width(width / 1.2)
          .height(150 * height / 768)
          .itemHeight(20)
          .itemMargin(3)
          .tickFormat({
            format: d3.timeFormat('%Y'),
            tickInterval: 1,
            tickSize: 6
          })
          .stack()
          .margin({
            left: 75,
            right: Math.round(125 * width / 1708),
            top: 0,
            bottom: 100
          })
          .mouseover(function (d, i, datum) {
// d is the current rendering object
// i is the index during d3 rendering
// datum is the id object

            graph.select('g')
              .selectAll('svg > g > text')
              .attr("pointer-events", "none");

// Create timeline tip
// console.log(d,i,datum);
            if (datum.class == 'leg') {
              tlTip.html(function () {
                return (datum.label + '</br><font size="1px">' + d.label + '</font>');
              });
            } else {
              tlTip.html(function () {
                return (datum.label + '</br><font size="1px">' + d.label + '</font></br>' + '<img style="width:70px; height:20px; display: block;" src="assets/static/images/knowlex.png">');
              });
            }
            graph.call(tlTip);
            tlTip.show();
          })
          .mouseout(function (d, i, datum) {
            tlTip.hide();
          })
          .click(function (d, i, datum) {
            if (datum.class == 'law') {
              window.location = "http://www.isislab.it:20080/knowlex";
            }
          })
          .scroll(function (x, scale) {

          });
      } else {
        var timelineContainer = d3.timelines()
          .width(width / 1.3)
          .height(150 * height / 768)
          .itemHeight(20)
          .itemMargin(10)
          .tickFormat({
            format: d3.timeFormat('%Y'),
            tickInterval: 1,
            tickSize: 6
          })
          .stack()
          .margin({
            left: 150,
            right: Math.round(180 * width / 1708),
            top: 0,
            bottom: 100
          })
          .mouseover(function (d, i, datum) {
// d is the current rendering object
// i is the index during d3 rendering
// datum is the id object

            graph.select('g')
              .selectAll('svg > g > text')
              .attr("pointer-events", "none");

// Create timeline tip
// console.log(d,i,datum);
            if (datum.class == 'leg') {
              tlTip.html(function () {
                return (datum.label + '</br><font size="2px">' + d.label + '</font>');
              });
            } else {
              tlTip.html(function () {
                return (datum.label + '</br><font size="2px">' + d.label + '</font></br>' + '<img style="display: block;" src="assets/static/images/knowlex.png">');
              });
            }
            graph.call(tlTip);
            tlTip.show();
          })
          .mouseout(function (d, i, datum) {
            tlTip.hide();
          })
          .click(function (d, i, datum) {
            if (datum.class == 'law') {
              window.location = "http://www.isislab.it:20080/knowlex";
            }
          })
          .scroll(function (x, scale) {

          });
      }
    }

    var graph = d3.select("#timeline1").append("svg").classed("timeline", true).attr("width", width)
      .datum(testData).call(timelineContainer);

    var timeline = d3.select('#timeline1 .timeline-xAxis');

    const svg = chart.append('g');

    var box = timeline.node().getBBox();

    var overlay = timeline.append("rect")
      .attr("class", "overlay")
      .attr("x", box.x)
      .attr("y", box.y)
      .attr("width", box.width)
      .attr("height", box.height)
      .on("mouseover", enableInteraction);

// Add the country label; the value is set on transition.
    var countrylabel = svg.append("text")
      .attr("class", "country label")
      .attr("text-anchor", "start")
      .attr("y", 50)
      .attr("x", 5)
      .text(" ");

    if(width>=360){
      countrylabel.attr("y",25);
      countrylabel.attr("x",5);
    }

    if(width>=480){
      countrylabel.attr("y",35);
      countrylabel.attr("x",5);
    }

    if(width>=720){
      countrylabel.attr("y",65);
      countrylabel.attr("x",5);
    }

    if(width>=1080){
      countrylabel.attr("y",70);
      countrylabel.attr("x",5);
    }

    const agelabel = svg.append("text")
      .attr("class", "age label")
      .attr("text-anchor", "start")
      .attr("y", (110*height/768))
      .attr("x", width-(width/2))
      .text($('#age-select option:selected').text());

    var bisect = d3.bisector(function(d) { return d[0]; });

    function td(d, y) { return interpolateValues(d.contratti_td, y); }
    function ti(d, y) { return interpolateValues(d.contratti_ti, y); }
    function rapporto(d, y) { if(isFinite(rapportoTdTi(d, y))) { return (rapportoTdTi(d, y)); } else {return 0; }}
    function nome(d) { return d.nome; }

    function rapportoTdTi(d, y) {
      return td(d, y) / ti(d, y);
    }

// Get absolute min and max
    let min = 100000, max=-100000;
    data.forEach(function (d) {

      const years = [2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016];

      years.forEach(function (y) {
        const value = rapporto(d, y);
        if (value < min) {
          min = value;
        }
        if (value > max) {
          max = value;
        }
      });
    });

// Draw Legend
    let w = 250,
      h = 50;

    const key = d3.select('#legend-container')
      .append('svg')
      .attr('id', 'legend')
      .attr('style', 'background: #fff')
      .attr('width', w)
      .attr('height', h);

    const legend = key.append('defs')
      .append('svg:linearGradient')
      .attr('id', 'gradient')
      .attr('x1', '0%')
      .attr('y1', '100%')
      .attr('x2', '100%')
      .attr('y2', '100%')
      .attr('spreadMethod', 'pad');

    legend.append('stop')
      .attr('offset', '0%')
      .attr('stop-color', '#FFED14')
      .attr('stop-opacity', 1);

    legend.append('stop')
      .attr('offset', '100%')
      .attr('stop-color', '#115d85')
      .attr('stop-opacity', 1);

    key.append('rect')
      .attr('width', w)
      .attr('height', h - 30)
      .style('fill', 'url(#gradient)')
      .attr('transform', 'translate(0,10)');

    const y = d3.scaleLinear()
      .range([w, 0])
      .domain([max, min]);

    const yAxis = d3.axisBottom()
      .scale(y)
      .ticks(4);

    key.append('g')
      .attr('class', 'x axis')
      .attr('transform', 'translate(0,30)')
      .call(yAxis)
      .append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', 0)
      .attr('dy', '.71em')
      .style('text-anchor', 'end')
      .text('axis title');

// Define colorScale
    const color = d3.scaleLinear()
      .domain([min, max])
      .range(['#FFED14', '#115d85']);

// Create tip
    const tip = d3.tip()
      .attr('data-html' , 'true')
      .attr('class', 'd3-tip')
      .attr('pointer-events', 'none')
      .offset([-10, 0])
      .html(function (d) {
        let regione;
        data.forEach(function (e) {
          if(e.nome === d.properties.NOME_REG) {
            regione = e;
          }
        });
        return ('<center>'+ nome(regione)+': '+rapporto(regione, year).toFixed(2)+'</center><br />Fixed-term contracts: '+td(regione, year)+"<br />Open-ended contracts: "+ti(regione, year));
      });
    chart.call(tip);

    function drawBase(year) {

// Load Topo.JSON and draw base chart
      d3.json('json/regioni_topo.json', function (error, world) {

        const regions = topojson.feature(world, world.objects.reg2011).features;
        topo = regions;

        const region = svg.selectAll('.region').data(topo);
        region.enter().insert('path')
          .attr('class', 'region')
          .attr('d', path)
          .style('fill', function (d) {
            let regione;
            data.forEach(function (r) {
              if(r.nome === d.properties.NOME_REG) {
                regione = r;
              }
            });
            return color(rapporto(regione, year));
          })
          // .on('mouseover', tip.show)
          // .on('mouseout', tip.hide)
          .on('mouseenter', function (d) {
            tip.show(d);
            countrylabel.text(d.properties.NOME_REG);
            region.style("opacity", .3);
            d3.select(this).style("opacity", 1);
            d3.selectAll(".selected").style("opacity", 1);
          })
          .on("mouseleave", function (d) {
            tip.hide(d);
            countrylabel.text("");
            region.style("opacity", 1);
          });
      });
    }

    function reColor(year) {

      tip.html(function (d) {
        let regione;
        data.forEach(function (e) {
          if(e.nome === d.properties.NOME_REG) {
            regione = e;
          }
        });
        return ('<center>'+ nome(regione)+' : <font color="red">'+rapporto(regione, year).toFixed(2)+'</font></center><br />Fixed-term contracts: <font color="red">'+td(regione, year)+"</font><br />Open-ended contracts: <font color=\"red\">"+ti(regione, year)+"</font>");
      });
      chart.call(tip);

// reColor chart
      const region = svg.selectAll('.region')
        .style('fill', function (d) {
          tip.hide(d);
          let regione;
          data.forEach(function (r) {
            if(r.nome === d.properties.NOME_REG) {
              regione = r;
            }
          });
          return color(rapporto(regione, year));
        })
        .on('mouseenter', function (d) {
          tip.show(d);
          console.log(d);
          countrylabel.text(d.properties.NOME_REG);
          region.style("opacity", .3);
          d3.select(this).style("opacity", 1);
        })
        .on('mouseleave', function (d) {
          tip.hide(d);
          countrylabel.text("");
          region.style("opacity", 1);
        })
        .on('mouseup', function (d) {
          tip.show(d);
          console.log(d);
          countrylabel.text(d.properties.NOME_REG);
          region.style("opacity", .3);
          d3.select(this)
            .style("opacity", 1);
        });
    }

    function displayYear(year) {
      graph.selectAll('.timelineSeries_leg, .timelineSeries_law').style("opacity", .3);
      graph.selectAll('.timelineSeries_leg, .timelineSeries_law').filter(function (d) {
// console.log(year, d.starting_time, d.ending_time);
        return year >= d.starting_time.getFullYear() && year <= d.ending_time.getFullYear()
      }).style("opacity", 1);
      timeline.selectAll('.tick').select('text').classed("current", false);
      timeline.selectAll('.tick').filter(function () {
        return d3.select(this).text() == Math.round(year);
      }).select('text').classed("current", true);
      reColor(Math.round(year));
    }

    function tweenYear() {
      var year = d3.interpolateNumber(2005, 2016);
      return function(t) { displayYear(year(t));};
    }

    function interpolateValues(values, year) {
      let c=0;
      values.forEach(function (v) {
        if(v[0] == year) {c = v[1];}
      });
      return c;
    }

// Start a transition that interpolates the data based on year.
    svg.transition()
      .ease(d3.easeLinear)
      .duration(8000)
      .tween("year", tweenYear)
      .on("end", enableInteraction);

    function enableInteraction() {
      var yearScale = d3.scaleLinear()
        .domain([2005, 2016])
        .range([box.x + 10, box.x + box.width - 10])
        .clamp(true);

// Cancel the current transition, if any.
      svg.transition().duration(0);

      overlay
        .on('mouseover', mouseover)
        .on('mouseout', mouseout)
        .on('mousemove', mousemove)
        .on('touchmove', mousemove);

      function mouseover() {
      }

      function mouseout() {
      }

      function mousemove() {
        displayYear(yearScale.invert(d3.mouse(this)[0]));
      }
    }


    const projection = d3.geoRobinson()
      .center([0*width/1708, 0])
      .scale(2300 * height / 768)
      .translate([250*width/1708, 2250 * height/ 768]);

    if(width>=360){
      projection.center([6,0]);
      projection.scale(2300 * (height/width) / (1708/768));
      projection.translate([0*width/1708, 2235 * (height/width)/ (1708/768)]);
    }

    if(width>=450){
      projection.center([6,0]);
      projection.scale(2100 * height / 768);
      projection.translate([0*width/1708, 2055 * height/ 768]);
    }

    if(width>=720){
      projection.center([6,0]);
      projection.scale(2300 * height / 960);
      projection.translate([0*width/1708, 2250 * height/ 960]);
    }

    if(width>=1080){
      projection.center([6,0]);
      projection.scale(2300 * height / 1080);
      projection.translate([0*width/1708, 2250 * height/ 1080]);
    }


    if(width>=1366){
      projection.center([0,0]);
      projection.scale(2300 * height / 768);
      projection.translate([250*width/1708, 2200 * height/ 768]);
    }
    const path = d3.geoPath()
      .projection(projection);

    drawBase(2005);





  });
}

switch ($('#age-select option:selected').val()) {
  case '1': drawGraph('json/regioni_map1.json'); break;
  case '2': drawGraph('json/regioni_map2.json'); break;
  case '3': drawGraph('json/regioni_map3.json'); break;
  case 'ALL': drawGraph('json/regioni_bubble.json'); break;
  default: break;
}

$('#age-select').change(function () {
  switch ($('#age-select option:selected').val()) {
    case '1': drawGraph('json/regioni_map1.json'); break;
    case '2': drawGraph('json/regioni_map2.json'); break;
    case '3': drawGraph('json/regioni_map3.json'); break;
    case 'ALL': drawGraph('json/regioni_bubble.json'); break;
    default: break;
  }
});

window.onresize = function () {
  console.log("Resize...");
  drawGraph(filename);
  console.log("Resized.");
};
