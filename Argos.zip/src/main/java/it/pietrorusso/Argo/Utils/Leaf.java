package it.pietrorusso.Argo.Utils;

import java.math.BigInteger;

public class Leaf extends Node {

    private BigInteger value;


    public Leaf() {

    }

    public Leaf(String nome) { super(nome);
    }

    public BigInteger getValue() {
        return value;
    }

    public void setValue(BigInteger value) {
        this.value = value;
    }
}
