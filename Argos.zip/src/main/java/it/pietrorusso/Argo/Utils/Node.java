package it.pietrorusso.Argo.Utils;

public class Node {

    private String name;


    public Node() {
    }

    public Node(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}