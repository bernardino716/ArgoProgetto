package it.pietrorusso.Argo.Controller;

import it.pietrorusso.Argo.Utils.Leaf;
import it.pietrorusso.Argo.Utils.Node;
import it.pietrorusso.Argo.Utils.Root;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;

@Controller
public class TreemapChartController {

    @RequestMapping(value = "/treemap_chart.html/json",
            method = RequestMethod.GET,
            produces = "application/json"
    )
    @ResponseBody
    public String standardJson() {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, true);
        String json = "error";

        try {
            JSONParser parser = new JSONParser(new FileReader(System.getProperty("catalina.base")+"/webapps/Argo/json/treemapData.json"));
//            JSONParser parser = new JSONParser(new FileReader("src/main/webapp/json/treemapData.json"));

            ArrayList<LinkedHashMap> data = (ArrayList<LinkedHashMap>) parser.parse();
            Root root = new Root("Contracts");
            loadData(root, data, "genere", "class_contratto", "istruzione");
            json = objectMapper.writeValueAsString(root);
            //System.out.println(json);
        }
        catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        return json;

    }

    @RequestMapping(
            value = "/treemap_chart.html/json",
            method = RequestMethod.GET,
            produces = "application/json",
            params = {"1","2","3"}
    )
    @ResponseBody
    public String paramJson(@RequestParam("1") String first, @RequestParam("2") String second, @RequestParam("3") String third ) {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, true);
        String json = "error";

        try {
            JSONParser parser = new JSONParser(new FileReader(System.getProperty("catalina.base")+"/webapps/Argo/json/treemapData.json"));
//            JSONParser parser = new JSONParser(new FileReader("src/main/webapp/json/treemapData.json"));
            ArrayList<LinkedHashMap> data = (ArrayList<LinkedHashMap>) parser.parse();
            Root root = new Root("Contracts");
            loadData(root, data, first, second, third);
            json = objectMapper.writeValueAsString(root);
            System.out.println("ASD");
        }
        catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        return json;
    }

    @RequestMapping(
            value = "/treemap_chart.html",
            method = RequestMethod.GET
    )
    @ResponseBody
    public ModelAndView MapChartController() {

        return new ModelAndView("/treemap.html");

    }

    private void loadData(Root root, ArrayList<LinkedHashMap> data, String first, String second, String third) {

        firstLevel(root, data, first);
        secondLevel(root, data, second);
        thirdLevel(root, data, third);
        populateValues(root, data, first, second);

    }

    private ArrayList<Object> LoadLevelNames(ArrayList<LinkedHashMap> data, String choice) {

        String tag = "";
        ArrayList<Object> names = new ArrayList<>();
        switch (choice) {
            case "genere": tag = "Genre"; break;
            case "class_contratto": tag = "Contract type"; break;
            case "istruzione": tag = "Educational level"; break;
        }

        for (LinkedHashMap<String, String> o : data) {
            if(!names.contains(o.get(tag))) {
                names.add(o.get(tag));
            }
        }
        //System.out.println(names);
        return names;
    }

    private ArrayList<String> LoadNestedLevelNames(LinkedHashMap<String, BigInteger> data) {

        ArrayList<String> names = new ArrayList<>();

        for (String s: data.keySet()) {
            if(!names.contains(s)) {
                names.add(s);
            }
        }
        //System.out.println(names);
        return names;
    }

    private void firstLevel(Root root, ArrayList<LinkedHashMap> data, String first) {
        try {

            switch(LoadLevelNames(data, first).get(0).getClass().getSimpleName()) {
                case "String": {
                    for (Object f : LoadLevelNames(data, first)) {
                        //System.out.println(f);
                        root.add(new Root((String) f));
                    }
                    break;
                }
                case "LinkedHashMap": {
                    Object f = LoadLevelNames(data, first).get(0);
                    //System.out.println(f);
                    for (String f1: LoadNestedLevelNames((LinkedHashMap<String, BigInteger>) f)) {
                        //System.out.println(f1);
                        root.add(new Root(f1));
                    }
                    break;
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void secondLevel(Root root, ArrayList<LinkedHashMap> data, String second) {

        try {

            switch(LoadLevelNames(data, second).get(0).getClass().getSimpleName()) {
                case "String": {
                    for (Object s : LoadLevelNames(data, second)) {
                        //System.out.println(s);
                        for (Node f: root.getChildren()) {
                            ((Root) f).add(new Root((String) s));
                        }
                    }
                    break;
                }
                case "LinkedHashMap": {
                    Object s = LoadLevelNames(data, second).get(0);
                    //System.out.println(s);
                    for (Node f: root.getChildren()) {
                        for (String s1 : LoadNestedLevelNames((LinkedHashMap<String, BigInteger>) s)) {
                            //System.out.println(s1);
                            ((Root) f).add(new Root(s1));
                        }
                    }
                    break;
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void thirdLevel(Root root, ArrayList<LinkedHashMap> data, String third) {

        try {

            switch(LoadLevelNames(data, third).get(0).getClass().getSimpleName()) {
                case "String": {
                    for (Object t : LoadLevelNames(data, third)) {
                        //System.out.println(t);
                        for (Node f: root.getChildren()) {
                            for (Node f2: ((Root) f).getChildren()) {
                                ((Root) f2).add(new Leaf((String) t));
                            }
                        }
                    }
                    break;
                }
                case "LinkedHashMap": {
                    Object t = LoadLevelNames(data, third).get(0);
                    for (Node f: root.getChildren()) {
                        for (Node f2: ((Root) f).getChildren()) {
                            for (String t1 : LoadNestedLevelNames((LinkedHashMap<String, BigInteger>) t)) {
                                //System.out.println(t1);
                                ((Root) f2).add(new Leaf(t1));
                            }
                        }
                    }
                    break;
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private LinkedHashMap<String, BigInteger> getValues(ArrayList<LinkedHashMap> data) {

        LinkedHashMap<String, BigInteger> entries = new LinkedHashMap<>();

        for (LinkedHashMap<String, Object> d: data) {

            String path = "";

            path = path.concat(d.get("Genre")+"/"+d.get("Contract type")+"/");

            for (String key: ((LinkedHashMap<String, Integer>) d.get("Educational level")).keySet()) {
                BigInteger value = ((LinkedHashMap<String, BigInteger>) d.get("Educational level")).get(key);
                //System.out.println(key + " " + value);
                entries.put(path.concat(key), value);
            }
        }
        //System.out.println(entries);
        return entries;
    }

    private void populateValues(Root root, ArrayList<LinkedHashMap> data, String first, String second)  {

        LinkedHashMap<String, BigInteger> values = getValues(data);
        //System.out.println(values);

        for (Node f: root.getChildren()) {
            for (Node f2: ((Root)f).getChildren()) {
                for (Node f3: ((Root)f2).getChildren()) {
                    String resourcePath = "";
                    switch (first+"/"+second) {
                        case "genere/class_contratto": resourcePath = resourcePath.concat(f.getName()+"/"+f2.getName()+"/"+f3.getName()); break;
                        case "genere/istruzione": resourcePath = resourcePath.concat(f.getName()+"/"+f3.getName()+"/"+f2.getName()); break;
                        case "class_contratto/genere": resourcePath = resourcePath.concat(f2.getName()+"/"+f.getName()+"/"+f3.getName()); break;
                        case "class_contratto/istruzione": resourcePath = resourcePath.concat(f3.getName()+"/"+f.getName()+"/"+f2.getName()); break;
                        case "istruzione/genere": resourcePath = resourcePath.concat(f2.getName()+"/"+f3.getName()+"/"+f.getName()); break;
                        case "istruzione/class_contratto": resourcePath = resourcePath.concat(f3.getName()+"/"+f2.getName()+"/"+f.getName()); break;
                    }
                    //System.out.println(values.get(resourcePath));
                    ((Leaf) f3).setValue(values.get(resourcePath));
                }
            }
        }


    }

}
